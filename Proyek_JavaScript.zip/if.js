let nilai = "90";
if (nilai > 80) {
    document.writeln ("A")
} else if (nilai > 70) {
   document.writeln ("B") 
} else if (nilai > 60) {
    document.writeln ("C")
} else {
document.writeln ("D")
}




